<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume - Chris Candidate</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            font-size: 13px;
        }
        .header {
            background-color: #2A5391;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
        }
        .header p {
            margin: 5px 0;
        }
        h3 {
            color: #2A5391;
            border-bottom: 1px solid #2A5391;
            padding-bottom: 5px;
        }
        .down_button:hover {
            transform: scale(1.2);
        }
        .left{
            margin-left:20px;
        }
    </style>
</head>
<body>
    <?php
    if (isset($_SESSION['resume'])) {
        $resume = $_SESSION['resume'];
    ?>
    <div class="container text-center my-3">
        <button id="download-pdf" class="btn btn-success down_button">Download as PDF</button>
    </div>
    <div id="resume" class="container">
        <div class="header">
            <h1><?php echo $resume['name']; ?></h1>
            <p><?php echo $resume['job_title']; ?></p>
            <p><?php echo $resume['address']; ?> | <?php echo $resume['phone']; ?> | <?php echo $resume['email']; ?> | <?php echo $resume['LinkedIn']; ?></p>
        </div>

        <div class="container mt-3 left">
            <?php if (!empty(trim($resume['career_objective']))) { ?>
                <h3>Career Objective</h3>
                <p><?php echo $resume['career_objective'] ?></p>
            <?php } ?>

            <?php if (!empty($resume['work_history']) && array_filter($resume['work_history'])) { ?>
                <h3>Professional Experience</h3>
                <ul>
                    <?php foreach ($resume['work_history'] as $work) { ?>
                        <?php if (!empty(trim($work))) { ?>
                            <li><?php echo $work ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            <?php } ?>

            <?php if (!empty($resume['qualifications']) && array_filter($resume['qualifications'])) { ?>
                <h3>Education</h3>
                <ul>
                    <?php foreach ($resume['qualifications'] as $edu) { ?>
                        <?php if (!empty(trim($edu))) { ?>
                            <li><?php echo $edu ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            <?php } ?>

            <?php if (!empty($resume['skills']) && array_filter($resume['skills'])) { ?>
                <h3>Skills</h3>
                <ul>
                    <?php foreach ($resume['skills'] as $skills) { ?>
                        <?php if (!empty(trim($skills))) { ?>
                            <li><?php echo $skills ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            <?php } ?>

            <?php if (!empty($resume['certifications']) && array_filter($resume['certifications'])) { ?>
                <h3>Certifications</h3>
                <ul>
                    <?php foreach ($resume['certifications'] as $cer) { ?>
                        <?php if (!empty(trim($cer))) { ?>
                            <li><?php echo $cer ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            <?php } ?>

            <?php if (!empty($resume['affiliations']) && array_filter($resume['affiliations'])) { ?>
                <h3>Affiliations</h3>
                <ul>
                    <?php foreach ($resume['affiliations'] as $aff) { ?>
                        <?php if (!empty(trim($aff))) { ?>
                            <li><?php echo $aff ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            <?php } ?>

            <?php if (!empty($resume['references']) && array_filter($resume['references'])) { ?>
                <h3>References</h3>
                <ul>
                    <?php foreach ($resume['references'] as $reference) { ?>
                        <?php if (!empty(trim($reference))) { ?>
                            <li><?php echo $reference ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            <?php } ?>

            <?php if (!empty($resume['hobbies']) && array_filter($resume['hobbies'])) { ?>
                <h3>Hobbies</h3>
                <ul>
                    <?php foreach ($resume['hobbies'] as $hobbies) { ?>
                        <?php if (!empty(trim($hobbies))) { ?>
                            <li><?php echo $hobbies ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            <?php } ?>

            <?php if (!empty($resume['language']) && array_filter($resume['language'])) { ?>
                <h3>Languages</h3>
                <ul>
                    <?php foreach ($resume['language'] as $lang) { ?>
                        <?php if (!empty(trim($lang))) { ?>
                            <li><?php echo $lang ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            <?php } ?>
        </div>
    </div>
    <?php } ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <script>
        document.getElementById('download-pdf').addEventListener('click', () => {
            const element = document.getElementById('resume');
            html2pdf().from(element).set({
                margin: -0.2,
                filename: 'resume.pdf',
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
            }).save();
        });
    </script>
</body>
</html>
