<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume - Pat Summers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            font-size: 13px;
            background-color: #f4f4f4;
            color: #333;
        }

        .resume-container {
            max-width: 800px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: auto;
            display: flex;
           
        }

        .sidebar {
            background-color: #fff;
            color: black;
            padding: 10px;
            box-sizing: border-box;
        }

        .main-content {
            padding: 20px;
            box-sizing: border-box;
            background-color: #D3DFEA;
            height:1120px;
        }

        .sidebar img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
            display: block;
            margin: 0 auto 10px;
        }

        .sidebar h1 {
            font-size: 1.5em;
            text-align: center;
            margin: 0 0 10px;
            color: #f06292;
        }

        .sidebar p {
            margin: 5px 0;
            text-align:left;
        }

        .section-title {
            font-size: 1.5em;
            border-bottom: 2px solid #f4f4f4;
            padding-bottom: 5px;
            margin-bottom: 10px;
            color: #044038;
            text-align:left;
        }

        ul {
            margin-top: -5px;
            text-align:left;
        }

        .skills,
        .work-history,
        .education {
            margin-bottom: 20px;
        }

        .skills ul,
        .work-history ul {
            list-style-type: none;
            padding: 0;
        }

        .skills li,
        .work-history li {
            margin-bottom: 10px;
        }

        .work-history h3,
        .work-history p {
            margin: 5px 0;
        }

        .down_button:hover {
            transform: scale(1.2);
        }
    </style>
</head>

<body class="container mt-5">

<div class="container text-center mb-4"> <!-- Added text-center class -->
        <button id="download-pdf" class="btn btn-success down_button">Download as PDF</button> <!-- Removed down_button class -->
    </div>
    <div class="container">
        <div id="resume" class="resume-container d-flex">
            <div class="col-md-4 sidebar text-center mt-4">
                <?php
                if (isset($_SESSION['resume'])) {
                    $resume = $_SESSION['resume'];
                    $resume_image_path = isset($resume['resume_image_path']) ? $resume['resume_image_path'] : '';
                } else {
                    $resume_image_path = '';
                }
                ?>
                <?php if (!empty($resume_image_path)): ?>
                    <img src="<?php echo $resume_image_path; ?>" alt="Pat Summers">
                <?php endif; ?>
                <h1 style="color:#044038"><?php echo $resume['name']; ?> (<?php echo $resume['job_title']; ?>)</h1><br>
                <p><strong>Email:</strong> <?php echo $resume['email']; ?></p>
                <p><strong>Phone:</strong> <?php echo $resume['phone']; ?></p>
                <p><strong>Location:</strong> <?php echo $resume['address']; ?></p>
                <?php if (!empty(trim($resume['LinkedIn']))) { ?>
                    <p><strong>LinkedIn:</strong> <?php echo $resume['LinkedIn']; ?></p>
                    <?php } ?> 
               <br>
                <h2 class="section-title">Education</h2>
                <ul>
                    <?php foreach ($resume['qualifications'] as $education) { ?>
                        <li><?php echo $education; ?></li>
                    <?php } ?>
                </ul>
                <h2 class="section-title">Hobbies</h2>
                <ul>
                    <?php foreach ($resume['hobbies'] as $hobbies) { ?>
                        <li><?php echo $hobbies; ?></li>
                    <?php } ?>
                </ul>
                <h2 class="section-title">Languages</h2>
                <ul>
                    <?php foreach ($resume['language'] as $language) { ?>
                        <li><?php echo $language; ?></li>
                    <?php } ?>
                </ul>
                <?php if (!empty($resume['certifications']) && array_filter($resume['certifications'])) { ?>
                <h2 class="section-title">Certification</h2>
                <ul>
                    <?php foreach ($resume['certifications'] as $certifications) { ?>
                        <?php if (!empty(trim($certifications))) { ?>
                        <li><?php echo $certifications; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
                <?php } ?>
            </div>
            <div class="col-md-8 main-content">
                <h2 class="section-title mt-4">Career Objective</h2>
                <p><?php echo $resume['career_objective']; ?></p>
                <h2 class="section-title">Professional Skills</h2>
                <ul>
                    <?php foreach ($resume['skills'] as $skill) { ?>
                        <li><?php echo $skill; ?></li>
                    <?php } ?>
                </ul>
                <h2 class="section-title">Work History</h2>
                <ul>
                    <?php foreach ($resume['work_history'] as $work) { ?>
                        <li><?php echo $work; ?></li>
                    <?php } ?>
                </ul>
                <?php if (!empty($resume['affiliations']) && array_filter($resume['affiliations'])) { ?>
                <h2 class="section-title">Affiliations</h2>
                <ul>
                    <?php foreach ($resume['affiliations'] as $affiliations) { ?>
                        <?php if (!empty(trim($affiliations))) { ?>
                        <li><?php echo $affiliations; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
                <?php } ?>

                <?php if (!empty($resume['references']) && array_filter($resume['references'])) { ?>
                <h2 class="section-title">Referrals</h2>
                <ul>
                    <?php foreach ($resume['references'] as $references) { ?>
                        <?php if (!empty(trim($references))) { ?>
                        <li><?php echo $references; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
                <?php } ?>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <script>
        document.getElementById('download-pdf').addEventListener('click', () => {
            const element = document.getElementById('resume');
            html2pdf().from(element).set({
                margin: 0,
                filename: 'resume.pdf',
                html2canvas: {
                    scale: 2
                },
                jsPDF: {
                    unit: 'in',
                    format: 'a4',
                    orientation: 'portrait'
                }
            }).save();
        });
    </script>
</body>

</html>
