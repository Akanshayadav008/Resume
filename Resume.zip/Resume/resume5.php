<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin-top: 30px;
            font-style: normal;
            font-size: 13px;
            padding: 0;
            background-color: #f0f0f0;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        #resume{
            height:1120px;
        }
        h2 {
            color: #355457;
        }
       .right-column {
            padding: 20px;
        }
        .left-column {
            background-color: #3e4e56;
            color: white;
         margin-top:0;
        }
        .left-column h1, .right-column h2 {
            font-size: 24px;
            margin: 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #ddd;
        }
        .left-column p, .right-column p, .right-column ul {
            margin: 10px 0;
        }
        .right-column ul {
            list-style-type: disc;
            padding-left: 20px;
        }
        .right-column ul li {
            margin-bottom: 10px;
        }
        .contact-info a {
            color: white;
            text-decoration: none;
        }
        .down_button:hover {
            transform: scale(1.2);
        }
        #download-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px; /* Adjust as needed */
        }
    </style>
</head>
<body>
    <?php
    if (isset($_SESSION['resume'])) {
        $resume = $_SESSION['resume'];
    ?>
     <div id="download-container">
            <button id="download-pdf" class="btn btn-success down_button">Download as PDF</button>
        </div>
    <div class="container">
   
        <div id="resume" class="row">
            <div class="col-md-4 left-column">
                <h1 style="margin-left:10px; margin-top:30px;"><?php echo $resume['name']; ?></h1>
                <p style="margin-left:10px;"><?php echo $resume['job_title']; ?></p>
                <div class="contact-info" style="margin-left:10px;">
                    <p><strong>Phone:</strong> <?php echo $resume['phone']; ?></p>
                    <p><strong>Email:</strong> <a href="mailto:<?php echo $resume['email']; ?>"><?php echo $resume['email']; ?></a></p>
                    <p><strong>Address:</strong><?php echo $resume['address']; ?></p>
                    <?php if (!empty(trim($resume['LinkedIn']))) { ?>
                    <p><strong>LinkedIn:</strong> <a href="<?php echo $resume['LinkedIn']; ?>" target="_blank"><?php echo $resume['LinkedIn']; ?></a></p>
                    <?php } ?>
                </div>
                <h3  style="margin-left:10px;">SKILLS</h3>
                <div style="border-bottom:1px solid grey; margin-bottom:5px;"></div>
                <ul>
                    <?php foreach ($resume['skills'] as $skill) { ?>
                        <li><?php echo $skill; ?></li>
                    <?php } ?>
                </ul>
                <?php if (!empty($resume['affiliations']) && array_filter($resume['affiliations'])) { ?>
                <h3 style="margin-left:10px;">Affiliations</h3>
                <div style="border-bottom:1px solid grey; margin-bottom:5px;"></div>
                <ul>
                    <?php foreach ($resume['affiliations'] as $affiliations) { ?>
                        <?php if (!empty(trim($affiliations))) { ?>
                        <li><?php echo $affiliations; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
                <?php } ?>
                <h3 style="margin-left:10px;">Hobbies</h3>
                <div style="border-bottom:1px solid grey; margin-bottom:5px;"></div>
                <ul>
                    <?php foreach ($resume['hobbies'] as $hobby) { ?>
                        <li><?php echo $hobby; ?></li>
                    <?php } ?>
                </ul>
                <h3 style="margin-left:10px;">Languages</h3>
                <div style="border-bottom:1px solid grey; margin-bottom:5px;"></div>
                <ul>
                    <?php foreach ($resume['language'] as $language) { ?>
                        <li><?php echo $language; ?></li>
                    <?php } ?>
                </ul>
            </div>
            <div class="col-md-8 right-column">
                <div class="section">
                    <h2 style="margin-top:20px;">SUMMARY/OBJECTIVE</h2>
                    <p><?php echo $resume['career_objective']; ?></p>
                </div>
                <br>
                <div class="section">
                    <h2>WORK EXPERIENCE</h2>
                    <ul>
                        <?php foreach ($resume['work_history'] as $experience) { ?>
                            <li><?php echo $experience; ?></li>
                        <?php } ?>
                    </ul>
                </div>
                <br>
                <div class="section">
                    <h2>EDUCATION</h2>
                    <ul>
                        <?php foreach ($resume['qualifications'] as $qualification) { ?>
                            <li><?php echo $qualification; ?></li>
                        <?php } ?>
                    </ul>
                </div>
                <br>
                <?php if (!empty($resume['certifications']) && array_filter($resume['certifications'])) { ?>
                <div class="section">
                    <h2>Certifications</h2>
                    <ul>
                        <?php foreach ($resume['certifications'] as $certifications) { ?>
                            <?php if (!empty(trim($certifications))) { ?>
                            <li><?php echo $certifications; ?></li>
                            <?php } ?>
                        <?php } ?>
                    </ul>
                </div>
                <br><?php } ?>
                <?php if (!empty($resume['references']) && array_filter($resume['references'])) { ?>
                <div class="section">
                    <h2>Reference</h2>
                    <ul>
                        <?php foreach ($resume['references'] as $references) { ?>
                            <?php if (!empty(trim($references))) { ?>
                            <li><?php echo $references; ?></li>
                        <?php } ?>
                        <?php } ?>
                    </ul>
                </div>
                <br><?php } ?>
            </div>
        </div>
     
    </div>
    <?php } ?>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- html2pdf library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <script>
        document.getElementById('download-pdf').addEventListener('click', () => {
            const element = document.getElementById('resume');
            html2pdf().from(element).set({
                margin: 0,
                filename: 'resume.pdf',
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
            }).save();
        });
    </script>
</body>
</html>
