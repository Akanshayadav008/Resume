<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chris Candidate - Resume</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
       
        }
        #resume {
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #f0e6cc;
            padding: 20px;
        }
        .header, .section-title {
            font-weight: bold;
        }
        .contact-info {
            margin-bottom: 20px;
        }
        .section-title {
            margin-top: 20px;
            border-bottom: 1px solid #000;
            padding-bottom: 5px;
        }
       
        .job-title {
            font-style: italic;
        }
        .job-details, .education-details {
            margin-bottom: 20px;
        }
        .bullet-points {
            margin: 0;
            padding-left: 20px;
        }
        .down_button:hover {
            transform: scale(1.2);
        }
    </style>
</head>
<body>
<?php
if (isset($_SESSION['resume'])) {
    $resume = $_SESSION['resume'];
?>
<div class="container my-4">
    <div class="text-center mb-4">
        <button id="download-pdf" class="btn btn-success down_button">Download as PDF</button>
    </div>
    <div id="resume" class="container">
        <div style="background-color:#f7d57e; margin-top:-20px;margin-left:-17px; margin-right:-17px;"><div class="header text-center">
            <h1><?php echo $resume['name']; ?></h1>
            <h2><?php echo $resume['job_title']; ?></h2>
        </div>
        <div class="contact-info text-center">
            <p><?php echo $resume['address']; ?><br>
            <?php echo $resume['phone']; ?><br>
            <a href="mailto:<?php echo $resume['email']; ?>" style="color:black; text-decoration:none;"><?php echo $resume['email']; ?></a></p>
        </div></div>
        <?php if (!empty(trim($resume['career_objective']))) { ?>
        <div class="professional-experience">
            <div class="section-title">Objective</div>
            <p><?php echo $resume['career_objective']; ?></p>
        </div>
        <?php } ?>
        <?php if (!empty($resume['work_history']) && array_filter($resume['work_history'])) { ?>
        <div class="professional-experience">
            <div class="section-title">Professional Experience</div>
            <div class="job-details">
                <ul class="bullet-points">
                    <?php foreach ($resume['work_history'] as $work) { ?>
                        <?php if (!empty(trim($work))) { ?>
                            <li><?php echo $work; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <?php } ?>
        <?php if (!empty($resume['skills']) && array_filter($resume['skills'])) { ?>
        <div class="education">
            <div class="section-title">Skills</div>
            <div class="education-details">
                <ul class="bullet-points">
                    <?php foreach ($resume['skills'] as $skill) { ?>
                        <?php if (!empty(trim($skill))) { ?>
                            <li><?php echo $skill; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <?php } ?>
        <?php if (!empty($resume['certifications']) && array_filter($resume['certifications'])) { ?>
        <div class="education">
            <div class="section-title">Certifications</div>
            <div class="education-details">
                <ul class="bullet-points">
                    <?php foreach ($resume['certifications'] as $certification) { ?>
                        <?php if (!empty(trim($certification))) { ?>
                            <li><?php echo $certification; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <?php } ?>
        <?php if (!empty($resume['references']) && array_filter($resume['references'])) { ?>
        <div class="education">
            <div class="section-title">References</div>
            <div class="education-details">
                <ul class="bullet-points">
                    <?php foreach ($resume['references'] as $reference) { ?>
                        <?php if (!empty(trim($reference))) { ?>
                            <li><?php echo $reference; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <?php } ?>
        <?php if (!empty($resume['affiliations']) && array_filter($resume['affiliations'])) { ?>
        <div class="education">
            <div class="section-title">Affiliations</div>
            <div class="education-details">
                <ul class="bullet-points">
                    <?php foreach ($resume['affiliations'] as $affiliation) { ?>
                        <?php if (!empty(trim($affiliation))) { ?>
                            <li><?php echo $affiliation; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <?php } ?>
        <?php if (!empty($resume['hobbies']) && array_filter($resume['hobbies'])) { ?>
        <div class="education">
            <div class="section-title">Hobbies</div>
            <div class="education-details">
                <ul class="bullet-points">
                    <?php foreach ($resume['hobbies'] as $hobby) { ?>
                        <?php if (!empty(trim($hobby))) { ?>
                            <li><?php echo $hobby; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <?php } ?>
        <?php if (!empty($resume['language']) && array_filter($resume['language'])) { ?>
        <div class="education">
            <div class="section-title">Languages</div>
            <div class="education-details">
                <ul class="bullet-points">
                    <?php foreach ($resume['language'] as $language) { ?>
                        <?php if (!empty(trim($language))) { ?>
                            <li><?php echo $language; ?></li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
<?php } ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
<script>
    document.getElementById('download-pdf').addEventListener('click', () => {
        const element = document.getElementById('resume');
        html2pdf().from(element).set({
            margin: 0,
            filename: 'resume.pdf',
            html2canvas: { scale: 2 },
            jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
        }).save();
    });
</script>
</body>
</html>
