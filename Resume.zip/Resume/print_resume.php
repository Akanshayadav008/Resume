<?php
// Start the session
session_start();

// Function to print data in the selected template
function printResume($template, $resumeData) {
    switch ($template) {
        case 1:
            include 'resume1.php';
            break;
        case 2:
            include 'resume2.php';
            break;
        case 3:
            include 'resume3.php';
            break;
        case 4:
            include 'resume4.php';
            break;
        case 5:
            include 'resume5.php';
            break;
        case 6:
            include 'resume6.php';
            break;
        case 7:
            include 'resume7.php';
            break;
        case 8:
            include 'resume8.php';
            break;
        case 9:
            include 'resume9.php';
            break;
        case 10:
            include 'resume10.php';
            break;
        case 11:
            include 'resume11.php';
            break; 
        
            default:
            echo "Invalid template selected.";
            break;
    }
}

// Check if resume data exists in session
if (isset($_SESSION['resume']) && isset($_GET['template'])) {
    $resume = $_SESSION['resume'];
    $template = intval($_GET['template']);
    
    // Print the resume using the selected template
    printResume($template, $resume);
} else {
    echo "No resume data found in the session or template not selected.";
}
?>
