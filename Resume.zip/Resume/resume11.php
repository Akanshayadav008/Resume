<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Resume</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .column {
            background-color: #948851;
            color: white;
            font-size: 13px;
            height: 1100px;
        }
        .down_button:hover {
            transform: scale(1.2);
        }
        .resume-section p, .resume-section ul {
            font-size: 13px;
        }
        .resume-section .divider {
            border-bottom: 1px solid #948851;
            margin-right: 30px;
            margin-bottom: 10px;
        }
        .contact-info i {
            color: #f7f7f7;
            margin-right: 10px;
        }
        #resume{
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius:10px;
        }
        .contact-info i.fa-location-dot {
            color: #f1f4f8;
        }
    </style>
</head>
<body class="container mt-5">
    <?php 
    if (isset($_SESSION['resume'])) {
        $resume = $_SESSION['resume'];
    ?>
    <div class="text-center mb-4">
        <button id="download-pdf" class="down_button btn btn-success">Download as PDF</button>
    </div>
    <div id="resume">
        <div class="row">
            <div class="col-lg-8 col-md-7">
                <div class="resume-section">
                    <div class="ml-3 mt-5">
                        <h1 style="color:#948851;"><?php echo $resume['name']; ?></h1><br><br>
                        <?php if (!empty(trim($resume['career_objective']))) { ?>
                        <h4 style=" color: #948851;">CAREER OBJECTIVE</h4>
                        <div class="divider"></div>
                        <p><?php echo $resume['career_objective']; ?></p>
                        <?php } ?>
                    </div>
                </div>
                
                <?php if (!empty($resume['work_history']) && array_filter($resume['work_history'])) { ?>
                <div class="resume-section">
                    <div class="ml-3 mt-3">
                        <h4 style=" color: #948851;">WORK HISTORY</h4>
                        <div class="divider"></div>
                        <ul>
                            <?php foreach ($resume['work_history'] as $work) { ?>
                            <?php if (!empty(trim($work))) { ?>
                            <li><?php echo $work; ?></li>
                            <?php } ?>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
                <?php } ?>

                <?php if (!empty($resume['references']) && array_filter($resume['references'])) { ?>
                <div class="resume-section">
                    <div class="ml-3 mt-3">
                        <h4 style=" color: #948851;">REFERENCE</h4>
                        <div class="divider"></div>
                        <ul>
                            <?php foreach ($resume['references'] as $reference) { ?>
                            <?php if (!empty(trim($reference))) { ?>
                            <li><?php echo $reference; ?></li>
                            <?php } ?>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
                <?php } ?>

                <?php if (!empty($resume['certifications']) && array_filter($resume['certifications'])) { ?>
                <div class="resume-section">
                    <div class="ml-3 mt-3">
                        <h4 style=" color: #948851;">CERTIFICATIONS</h4>
                        <div class="divider"></div>
                        <ul>
                            <?php foreach ($resume['certifications'] as $certification) { ?>
                            <?php if (!empty(trim($certification))) { ?>
                            <li><?php echo $certification; ?></li>
                            <?php } ?>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
                <?php } ?>
            </div>
            <div class="col-lg-4 col-md-5 column">
                <div class="contact-info mt-5 ml-3">
                    <i class="fa-solid fa-location-dot"></i><?php echo $resume['address']; ?><br><br>
                    <i class="fa-solid fa-phone"></i><?php echo $resume['phone']; ?><br><br>
                    <i class="fa-solid fa-envelope"></i><?php echo $resume['email']; ?><br><br>
                    <?php if (!empty(trim($resume['LinkedIn']))) { ?>
                    <i class="fa-brands fa-linkedin"></i><?php echo $resume['LinkedIn']; ?>
                    <?php } ?>                </div>

                <?php if (!empty($resume['skills']) && array_filter($resume['skills'])) { ?>
                <div class="resume-section mt-4 ml-3">
                    <h4>SKILLS</h4>
                    <div class="divider bg-white" style="border-bottom:0.2px solid #f0eeeb;"></div><br>
                    <ul>
                        <?php foreach ($resume['skills'] as $skill) { ?>
                        <?php if (!empty(trim($skill))) { ?>
                        <li><?php echo $skill ?></li>
                        <?php } ?>
                        <?php } ?>
                    </ul>
                </div>
                <?php } ?>

                <?php if (!empty($resume['qualifications']) && array_filter($resume['qualifications'])) { ?>
                <div class="resume-section mt-4 ml-3">
                    <h4>EDUCATION</h4>
                    <div class="divider bg-white" style="border-bottom:0.2px solid #f0eeeb;"></div><br>
                    <ul>
                        <?php foreach ($resume['qualifications'] as $qualification) { ?>
                        <?php if (!empty(trim($qualification))) { ?>
                        <li><?php echo $qualification ?></li>
                        <?php } ?>
                        <?php } ?>
                    </ul>
                </div>
                <?php } ?>

                <?php if (!empty($resume['affiliations']) && array_filter($resume['affiliations'])) { ?>
                <div class="resume-section mt-4 ml-3">
                    <h4>AFFILIATION</h4>
                    <div class="divider bg-white" style="border-bottom:0.2px solid #f0eeeb;"></div><br>
                    <ul>
                        <?php foreach ($resume['affiliations'] as $affiliation) { ?>
                        <?php if (!empty(trim($affiliation))) { ?>
                        <li><?php echo $affiliation ?></li>
                        <?php } ?>
                        <?php } ?>
                    </ul>
                </div>
                <?php } ?>

                <?php if (!empty($resume['hobbies']) && array_filter($resume['hobbies'])) { ?>
                <div class="resume-section mt-4 ml-3">
                    <h4>HOBBIES</h4>
                    <div class="divider bg-white" style="border-bottom:0.2px solid #f0eeeb;"></div><br>
                    <ul>
                        <?php foreach ($resume['hobbies'] as $hobby) { ?>
                        <?php if (!empty(trim($hobby))) { ?>
                        <li><?php echo $hobby ?></li>
                        <?php } ?>
                        <?php } ?>
                    </ul>
                </div>
                <?php } ?>

                <?php if (!empty($resume['language']) && array_filter($resume['language'])) { ?>
                <div class="resume-section mt-4 ml-3">
                    <h4>LANGUAGES</h4>
                    <div class="divider bg-white" style="border-bottom:0.2px solid #f0eeeb;"></div><br>
                    <ul>
                        <?php foreach ($resume['language'] as $language) { ?>
                        <?php if (!empty(trim($language))) { ?>
                        <li><?php echo $language ?></li>
                        <?php } ?>
                        <?php } ?>
                    </ul>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php } ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <script>
        document.getElementById('download-pdf').addEventListener('click', () => {
            const element = document.getElementById('resume');
            html2pdf().from(element).set({
                margin: 0,
                filename: 'resume.pdf',
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
            }).save();
        });
    </script>
    </body>
    </html>
