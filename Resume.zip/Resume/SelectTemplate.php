<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Select Resume Template</title>
    <style>
        .template-container {
            position: relative;
            display: inline-block;
            margin: 10px;
            transition: transform 0.2s;
        }
        .template-container:hover {
            transform: scale(1.2);
        }
        .template-image {
            width: 200px;
            height: 300px;
            cursor: pointer;
            border: 2px solid transparent;
            border-radius: 5px;
        }
        .template-image.selected {
            border: 2px solid blue;
        }
        .preview-button {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            opacity: 0;
            transition: opacity 0.2s;
        }
        .template-container:hover .preview-button {
            opacity: 1;
        }
        .preview {
            align-items: center;
            background-color: #2dbd64;
            width: 10%;
            border-radius: 5px;
            border: 1px solid grey;
            height: 30px;
            color: white;
        }
        .preview-button{
            background-color: #998653;
        }
    </style>
</head>
<body>
    <h1 style="text-align:center">Select Resume Template</h1>
    <form id="templateForm" action="print_resume.php" method="GET">
        <input type="hidden" id="templateInput" name="template">
        <br><br>
        <div style="display: flex; flex-wrap: wrap; justify-content: center;">
            <div class="template-container">
                <img src="image/resume1.jpg" class="template-image" data-template="1" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume2.jpg" class="template-image" data-template="2" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume3.jpg" class="template-image" data-template="3" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume4.jpg" class="template-image" data-template="4" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume5.jpg" class="template-image" data-template="5" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume6.jpg" class="template-image" data-template="6" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume7.jpg" class="template-image" data-template="7" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume8.jpg" class="template-image" data-template="8" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume9.jpg" class="template-image" data-template="9" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume10.jpg" class="template-image" data-template="10" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume11.jpg" class="template-image" data-template="11" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
            <div class="template-container">
                <img src="images/resume12.jpg" class="template-image" data-template="12" onclick="selectTemplate(this)">
                <button type="button" class="preview-button" onclick="selectTemplate(this.previousElementSibling)">Preview</button>
            </div>
        </div>
        <br>
    </form>

    <script>
        function selectTemplate(element) {
            // Deselect all images
            var images = document.getElementsByClassName('template-image');
            for (var i = 0; i < images.length; i++) {
                images[i].classList.remove('selected');
            }

            // Select the clicked image
            element.classList.add('selected');

            // Set the selected template in the hidden input field
            document.getElementById('templateInput').value = element.getAttribute('data-template');

            // Submit the form
            document.getElementById('templateForm').submit();
        }
    </script>
</body>
</html>
