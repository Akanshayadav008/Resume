<!DOCTYPE html>
<html>
<head>
    <title>Resume Submission Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: Arial, sans-serif;
            font-style:normal;
            font-size:13px;
            margin: 20px;
            background-color: #f4f4f9;
        }
        h2 {
            color: #333;
        }
        form {
            background: #fff ;
            padding: 20px;
            width:60%;
            margin: 0 auto;
            border-radius: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        } 
        label {
            display: block;
            margin-top: 20px;
            color:#0a1012;
        }
        input, textarea, button {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-right:30px;
            width: 70%;
            border: 1px solid #ccc;
            border-radius: 4px; 
        }
        button.add-btn {
            width: auto;
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            margin-top: 10px;
        }
        button.add-btn:hover {
            background-color: #218838;
        }
        .section {
            margin-bottom: 20px;
        }
    </style>
    <script>
        function addField(sectionId, inputName) {
            const section = document.getElementById(sectionId);
            const input = document.createElement('input');
            input.type = 'text';
            input.name = inputName;
            section.appendChild(input);
        }
    </script>
</head>
<body><br>
    <h1 style="text-align:center">Submit Your Resume</h1><br>
    <form action="session.php" method="POST" enctype="multipart/form-data">
        <div style="display:flex; justify-content:space-between">
            <div>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name"style="text-transform: capitalize;"  required></div>
        <div>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required></div>
        <div>
        <label for="phone">Phone:</label>
        <input type="tel" id="phone" name="phone" maxlength="10"  pattern="\d{10}"required></div>
    </div>
    <label for="profile_picture">Profile Picture:</label>
        <input type="file" name="resume_image" id="resume_image" accept="image/*"><br>

    <label for="phone">LinkedIn:</label>
    <input type="text" id="phone" name="LinkedIn"></div>

        <label for="address">Address:</label>
        <textarea id="address" name="address" required></textarea>

        <label for="address">Career Objective</label>
        <textarea id="career_objective" name="career_objective" required></textarea>

        <div class="section">
            <label for="work_history">Qualifications:</label>
            <div id="qualifications">
                <input type="text" name="qualifications[]" required>
            </div>
            <button type="button" class="add-btn" onclick="addField('qualifications', 'qualifications[]')"><i class="fa-solid fa-plus" style="color: #f2f2f2; margin-right: 5px"></i>Add</button>
        </div>

 
        <label for="job_title">Job Title:</label>
        <input type="text" id="job_title" name="job_title" required>
        <div class="section">
            <label for="work_history">Work History/Experience:</label>
            <div id="work_history">
                <input type="text" name="work_history[]" required>
            </div>
            <button type="button" class="add-btn" onclick="addField('work_history', 'work_history[]')"><i class="fa-solid fa-plus" style="color: #f2f2f2; margin-right: 5px"></i>Add</button>
        </div>

        <div class="section">
            <label for="skills">Skills:</label>
            <div id="skills">
                <input type="text" name="skills[]" required>
            </div>
            <button type="button" class="add-btn" onclick="addField('skills', 'skills[]')"><i class="fa-solid fa-plus" style="color: #f2f2f2; margin-right: 5px"></i>Add</button>
        </div>

        <div class="section">
            <label for="references">References:</label>
            <div id="references">
                <input type="text" name="references[]" >
            </div>
            <button type="button" class="add-btn" onclick="addField('references', 'references[]')"><i class="fa-solid fa-plus" style="color: #f2f2f2; margin-right: 5px"></i>Add</button>
        </div>
        
        <div class="section">
            <label for="work_history">Affiliations:</label>
            <div id="affiliations">
                <input type="text" name="affiliations[]" >
            </div>
            <button type="button" class="add-btn" onclick="addField('affiliations', 'affiliations[]')"><i class="fa-solid fa-plus" style="color: #f2f2f2; margin-right: 5px"></i>Add</button>
        </div>
        
        
        <div class="section">
            <label for="work_history">Hobbies:</label>
            <div id="hobbies">
                <input type="text" name="hobbies[]" required>
            </div>
            <button type="button" class="add-btn" onclick="addField('hobbies', 'hobbies[]')"><i class="fa-solid fa-plus" style="color: #f2f2f2; margin-right: 5px"></i>Add</button>
        </div>
        
        <div class="section">
            <label for="work_history">Languages:</label>
            <div id="language">
                <input type="text" name="language[]" required>
            </div>
            <button type="button" class="add-btn" onclick="addField('language', 'language[]')"><i class="fa-solid fa-plus" style="color: #f2f2f2; margin-right: 5px"></i>Add</button>
        </div>
        <div class="section">
            <label for="work_history"> Certifications:</label>
            <div id="certifications">
                <input type="text" name="certifications[]" >
            </div>
            <button type="button" class="add-btn" onclick="addField('certifications', 'certifications[]')"><i class="fa-solid fa-plus" style="color: #f2f2f2; margin-right: 5px"></i>Add</button>
        </div>
     
        <br><br>
        <div style="display:flex; justify-content:center;">
        <input type="submit" style="background-color:green; width:20%; color:white;" value="Submit"></div>
    </form>
</body>
</html>
