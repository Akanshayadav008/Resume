<?php
// Start the session
session_start();

// Store form data in session variables
$_SESSION['resume'] = array(
    'name' => $_POST['name'],
    'email' => $_POST['email'],
    'phone' => $_POST['phone'],
    'address' => $_POST['address'],
    'qualifications' => $_POST['qualifications'],
    'summary_qualifications' => $_POST['summary_qualifications'],
    'career_objective' => $_POST['career_objective'],
    'certifications' => $_POST['certifications'],
    'affiliations' => $_POST['affiliations'],
    'work_history' => $_POST['work_history'],
    'skills' => $_POST['skills'],
    'references' => $_POST['references'],
    'job_title' => $_POST['job_title'],
    'LinkedIn' => $_POST['LinkedIn'],
    'hobbies' => $_POST['hobbies'],
    'language' => $_POST['language']
);

if (isset($_FILES['resume_image']) && $_FILES['resume_image']['error'] === UPLOAD_ERR_OK) {
    $temp_name = $_FILES['resume_image']['tmp_name'];
    $original_name = $_FILES['resume_image']['name'];
    $file_extension = pathinfo($original_name, PATHINFO_EXTENSION);
    
    // Example: Save the file to a folder and store its path in session
    $upload_directory = 'uploads/';
    $new_filename = 'resume_image_' . uniqid() . '.' . $file_extension;
    $upload_path = $upload_directory . $new_filename;
    
    // Move uploaded file to designated folder
    if (move_uploaded_file($temp_name, $upload_path)) {
        $_SESSION['resume']['resume_image_path'] = $upload_path; // Store path in session
    } else {
        // Handle file upload error
        echo "Failed to move uploaded file.";
    }
}


// Optionally, you can redirect the user after storing data
header('Location: SelectTemplate.php');
exit();
?>